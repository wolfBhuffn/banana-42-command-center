    let currentRole = 'OPERATOR';

    function selectRole(role) {
      currentRole = role;
      const btnOperator = document.getElementById('btnOperator');
      const btnGuest = document.getElementById('btnGuest');
      const passcodeGroup = document.getElementById('passcodeGroup');
      const passcode = document.getElementById('passcode');

      if (role === 'GUEST') {
        btnGuest.classList.add('active');
        btnOperator.classList.remove('active');
        passcodeGroup.style.display = 'none';
        passcode.removeAttribute('required');
      } else {
        btnOperator.classList.add('active');
        btnGuest.classList.remove('active');
        passcodeGroup.style.display = 'block';
        passcode.setAttribute('required', 'required');
      }
    }

    function handleAuth(event) {
      event.preventDefault();
      const identifier = document.getElementById('identifier').value.trim();
      const passcode = document.getElementById('passcode').value;
      const statusMsg = document.getElementById('statusMsg');

      statusMsg.className = 'status-msg';
      statusMsg.textContent = 'AUTHENTICATING SECURE CLEARANCE...';

      setTimeout(() => {
        if (currentRole === 'GUEST') {
          localStorage.setItem('banana42_session', JSON.stringify({
            role: 'GUEST',
            user: identifier || 'Guest_User',
            authTime: new Date().toISOString()
          }));
          statusMsg.className = 'status-msg success';
          statusMsg.textContent = 'GUEST ACCESS GRANTED. REDIRECTING...';
          setTimeout(() => { window.location.href = 'dashboard.html'; }, 600);
          return;
        }

        // Default local secret passkey check (customizable)
        if (passcode.length > 0) {
          localStorage.setItem('banana42_session', JSON.stringify({
            role: 'OPERATOR',
            user: identifier || 'wolfX_Xsabyter',
            authTime: new Date().toISOString()
          }));
          statusMsg.className = 'status-msg success';
          statusMsg.textContent = 'CLEARANCE VERIFIED. ACCESS GRANTED.';
          setTimeout(() => { window.location.href = 'dashboard.html'; }, 600);
        } else {
          statusMsg.className = 'status-msg error';
          statusMsg.textContent = 'ACCESS DENIED: INVALID PASSCODE';
        }
      }, 400);
    }