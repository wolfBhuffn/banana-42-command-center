document.addEventListener('DOMContentLoaded', () => {
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const mobileDrawer = document.getElementById('mobileDrawer');

  if (hamburgerBtn && mobileDrawer) {
    hamburgerBtn.addEventListener('click', () => {
      mobileDrawer.classList.toggle('active');
    });
  }

  const updateHeaderAuthState = () => {
    const session = JSON.parse(localStorage.getItem('banana42_session') || 'null');
    const headerAuthBtn = document.getElementById('headerAuthBtn');
    const headerAuthText = document.getElementById('headerAuthText');
    const mobileAuthLink = document.getElementById('mobileAuthLink');

    if (session && session.authenticated) {
      if (headerAuthText) headerAuthText.textContent = "LOGOUT (" + session.role + ")";
      if (mobileAuthLink) mobileAuthLink.textContent = "Logout (" + session.operatorId + ")";
      
      if (headerAuthBtn) {
        headerAuthBtn.onclick = (e) => {
          const href = headerAuthBtn.getAttribute('href');
          if (href === 'login.html' || href === 'pages/login.html') {
            e.preventDefault();
            localStorage.removeItem('banana42_session');
            window.location.reload();
          }
        };
      }
    }
  };

  updateHeaderAuthState();

  const loginForm = document.getElementById('loginForm');
  const authAlert = document.getElementById('authAlert');
  const demoOperatorBtn = document.getElementById('demoOperatorBtn');
  const demoGuestBtn = document.getElementById('demoGuestBtn');

  const showAlert = (message, type = 'error') => {
    if (!authAlert) return;
    authAlert.textContent = message;
    authAlert.className = "auth-alert " + type;
  };

  const authenticateUser = (operatorId, role) => {
    const sessionData = {
      operatorId: operatorId || 'wolfX_Xsabyter',
      role: role || 'OPERATOR',
      authenticated: true,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('banana42_session', JSON.stringify(sessionData));
    showAlert("ACCESS GRANTED: WELCOME " + sessionData.operatorId, "success");
    setTimeout(() => {
      window.location.href = '../index.html';
    }, 1000);
  };

  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const operatorId = document.getElementById('operatorId').value.trim();
      const passkey = document.getElementById('passkey').value.trim();
      if (!passkey) {
        showAlert("PLEASE ENTER ACCESS PASSKEY", "error");
        return;
      }
      authenticateUser(operatorId, 'OPERATOR');
    });
  }

  if (demoOperatorBtn) {
    demoOperatorBtn.addEventListener('click', () => authenticateUser('wolfX_Xsabyter', 'OPERATOR'));
  }
  if (demoGuestBtn) {
    demoGuestBtn.addEventListener('click', () => authenticateUser('GUEST_USER', 'GUEST'));
  }
});
